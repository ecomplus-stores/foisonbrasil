export default options => {
  console.log('Addi widget started with EJS appends')
}
